module.exports = {
    name: 'guildMemberAdd',
    async execute(member) {
        // Sadece belirli sunucuda çalışsın
        if (member.guild.id !== '1364654347908026378') return;

        try {
            // Rolü ver
            const role = member.guild.roles.cache.get('1365664101480534048');
            if (role) {
                await member.roles.add(role);
            }

            // Hoşgeldin kanalını bul
            const welcomeChannel = member.guild.channels.cache.get('1365662336421073026');
            if (!welcomeChannel) return;

            // Hoşgeldin embed'i oluştur
            const welcomeEmbed = {
                color: 0x2ecc71,
                title: '🎉 Yeni Üye Katıldı!',
                description: `Hoş geldin ${member}! Sunucumuza katıldığın için teşekkürler!`,
                thumbnail: {
                    url: member.user.displayAvatarURL({ dynamic: true })
                },
                fields: [
                    {
                        name: '👥 Üye Sayısı',
                        value: `Seninle birlikte **${member.guild.memberCount}** kişi olduk!`,
                        inline: true
                    },
                    {
                        name: '📅 Hesap Oluşturulma',
                        value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
                        inline: true
                    }
                ],
                timestamp: new Date(),
                footer: {
                    text: member.guild.name,
                    icon_url: member.guild.iconURL({ dynamic: true })
                }
            };

            await welcomeChannel.send({ 
                content: `${member}`,
                embeds: [welcomeEmbed]
            });

        } catch (error) {
            console.error('Hoşgeldin mesajı gönderilirken hata:', error);
        }
    }
}; 